var JPiece_8cs =
[
    [ "game.logic.tilespawner.JPiece", "classgame_1_1logic_1_1tilespawner_1_1JPiece.html", "classgame_1_1logic_1_1tilespawner_1_1JPiece" ]
];