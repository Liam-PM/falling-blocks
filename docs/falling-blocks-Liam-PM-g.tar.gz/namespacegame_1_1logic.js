var namespacegame_1_1logic =
[
    [ "EventQueue", "namespacegame_1_1logic_1_1EventQueue.html", "namespacegame_1_1logic_1_1EventQueue" ],
    [ "playfield", "namespacegame_1_1logic_1_1playfield.html", "namespacegame_1_1logic_1_1playfield" ],
    [ "tile", "namespacegame_1_1logic_1_1tile.html", "namespacegame_1_1logic_1_1tile" ],
    [ "tilespawner", "namespacegame_1_1logic_1_1tilespawner.html", "namespacegame_1_1logic_1_1tilespawner" ],
    [ "GravityService", "classgame_1_1logic_1_1GravityService.html", "classgame_1_1logic_1_1GravityService" ],
    [ "IGravityService", "interfacegame_1_1logic_1_1IGravityService.html", "interfacegame_1_1logic_1_1IGravityService" ],
    [ "IGravityStrategy", "interfacegame_1_1logic_1_1IGravityStrategy.html", "interfacegame_1_1logic_1_1IGravityStrategy" ],
    [ "LevelBasedGravityStrategy", "classgame_1_1logic_1_1LevelBasedGravityStrategy.html", "classgame_1_1logic_1_1LevelBasedGravityStrategy" ],
    [ "TimeBasedGravityStrategy", "classgame_1_1logic_1_1TimeBasedGravityStrategy.html", "classgame_1_1logic_1_1TimeBasedGravityStrategy" ]
];