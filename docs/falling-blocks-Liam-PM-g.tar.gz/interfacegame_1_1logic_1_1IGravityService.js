var interfacegame_1_1logic_1_1IGravityService =
[
    [ "CurrentGravity", "interfacegame_1_1logic_1_1IGravityService.html#ab84f19cc336ce42a46030108d6995cba", null ]
];