var searchData=
[
  ['zpiece_0',['ZPiece',['../classgame_1_1logic_1_1tilespawner_1_1ZPiece.html',1,'game::logic::tilespawner']]],
  ['zpiece_2ecs_1',['ZPiece.cs',['../ZPiece_8cs.html',1,'']]]
];
