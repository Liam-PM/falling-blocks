var searchData=
[
  ['dispatcher_0',['Dispatcher',['../classGameInitialiser.html#a631146436825c8eb568d387c678638ca',1,'GameInitialiser']]]
];
