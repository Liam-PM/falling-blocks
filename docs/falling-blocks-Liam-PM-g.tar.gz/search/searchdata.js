var indexSectionsWithContent =
{
  0: "._abcdefghijlmnoprstuvwxyz",
  1: "deghijlmopstuvz",
  2: "dgn",
  3: ".adeghijloprstuvz",
  4: "acdeghloprstuvw",
  5: "_cdfgprst",
  6: "r",
  7: "e",
  8: "su",
  9: "acghinstuwxy",
  10: "abd"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "properties",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Properties",
  10: "Pages"
};

