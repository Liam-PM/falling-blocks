var searchData=
[
  ['name_0',['Name',['../classdocumentation__evaluation_1_1person_1_1Person.html#a89f2bd12eebe7ae75d3b5c451c8b3346',1,'documentation_evaluation.person.Person.Name'],['../classdocumentation__evaluation_1_1person_1_1PersonViewModel.html#a838422101033a721f7c23c21c10e23ef',1,'documentation_evaluation.person.PersonViewModel.Name']]]
];
