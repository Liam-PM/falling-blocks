var searchData=
[
  ['username_0',['Username',['../classgame_1_1logic_1_1EventQueue_1_1UserLoginEvent.html#a6ed08775aafe7990ff4e483c0545795b',1,'game::logic::EventQueue::UserLoginEvent']]]
];
