var searchData=
[
  ['win_0',['Win',['../classScoreSubmit.html#ae8cd5fdf8c774668bd4d4cf0a005e2fc',1,'ScoreSubmit']]]
];
