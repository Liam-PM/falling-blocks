var searchData=
[
  ['userloginevent_0',['UserLoginEvent',['../classgame_1_1logic_1_1EventQueue_1_1UserLoginEvent.html',1,'game::logic::EventQueue']]],
  ['userservice_1',['UserService',['../classnetwork_1_1user_1_1UserService.html',1,'network::user']]]
];
