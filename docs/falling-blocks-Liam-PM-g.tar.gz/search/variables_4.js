var searchData=
[
  ['gravityincreaseperlevel_0',['GravityIncreasePerLevel',['../classgame_1_1logic_1_1LevelBasedGravityStrategy.html#ac7e1eba8beb7586012b3f8499bf8b667',1,'game::logic::LevelBasedGravityStrategy']]]
];
