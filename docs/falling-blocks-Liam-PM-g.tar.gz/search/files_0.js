var searchData=
[
  ['_2enetframework_2cversion_3dv4_2e7_2eassemblyattributes_2ecs_0',['.NETFramework,Version=v4.7.AssemblyAttributes.cs',['../_8NETFramework_00Version_0av4_87_8AssemblyAttributes_8cs.html',1,'']]]
];
