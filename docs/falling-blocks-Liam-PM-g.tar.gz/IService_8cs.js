var IService_8cs =
[
    [ "game.service.IService", "interfacegame_1_1service_1_1IService.html", null ]
];