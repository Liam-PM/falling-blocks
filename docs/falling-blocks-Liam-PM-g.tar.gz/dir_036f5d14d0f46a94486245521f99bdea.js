var dir_036f5d14d0f46a94486245521f99bdea =
[
    [ "score", "dir_6276bedd4b417fb9f320f9e90279f791.html", "dir_6276bedd4b417fb9f320f9e90279f791" ],
    [ "user", "dir_4d70f3a87c5cd5e79705377451ad52dc.html", "dir_4d70f3a87c5cd5e79705377451ad52dc" ],
    [ "HttpRequest.cs", "HttpRequest_8cs.html", "HttpRequest_8cs" ],
    [ "HttpRequestFactory.cs", "HttpRequestFactory_8cs.html", "HttpRequestFactory_8cs" ],
    [ "IHttpRequest.cs", "IHttpRequest_8cs.html", "IHttpRequest_8cs" ]
];