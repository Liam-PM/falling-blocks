var IPiece_8cs =
[
    [ "game.logic.tilespawner.IPiece", "classgame_1_1logic_1_1tilespawner_1_1IPiece.html", "classgame_1_1logic_1_1tilespawner_1_1IPiece" ]
];