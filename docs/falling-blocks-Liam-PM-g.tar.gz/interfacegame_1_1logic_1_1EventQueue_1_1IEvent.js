var interfacegame_1_1logic_1_1EventQueue_1_1IEvent =
[
    [ "Id", "interfacegame_1_1logic_1_1EventQueue_1_1IEvent.html#a307c56730363fc273d2069f83257c5ae", null ],
    [ "Source", "interfacegame_1_1logic_1_1EventQueue_1_1IEvent.html#a49f2a7e9ecddd0d532af39973adac177", null ]
];