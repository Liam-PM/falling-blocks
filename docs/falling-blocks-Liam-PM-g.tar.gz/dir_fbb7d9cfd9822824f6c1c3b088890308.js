var dir_fbb7d9cfd9822824f6c1c3b088890308 =
[
    [ "EventQueue", "dir_14c15a176da523ab9156642fa335aac3.html", "dir_14c15a176da523ab9156642fa335aac3" ],
    [ "playfield", "dir_40e79d3bfe8ec0a32243c6cac7b06aa7.html", "dir_40e79d3bfe8ec0a32243c6cac7b06aa7" ],
    [ "tile", "dir_3bae640fe08e07f822f4abbf4e309b2d.html", "dir_3bae640fe08e07f822f4abbf4e309b2d" ],
    [ "tilespawner", "dir_721b043b1284adeff4fd34e5e088f9d6.html", "dir_721b043b1284adeff4fd34e5e088f9d6" ],
    [ "Gravity.cs", "Gravity_8cs.html", "Gravity_8cs" ],
    [ "IDroppable.cs", "IDroppable_8cs.html", "IDroppable_8cs" ],
    [ "IGravityService.cs", "IGravityService_8cs.html", "IGravityService_8cs" ],
    [ "IGravityStrategy.cs", "IGravityStrategy_8cs.html", "IGravityStrategy_8cs" ],
    [ "LevelBasedGravityStrategy.cs", "LevelBasedGravityStrategy_8cs.html", "LevelBasedGravityStrategy_8cs" ],
    [ "TimeBasedGravityStrategy.cs", "TimeBasedGravityStrategy_8cs.html", "TimeBasedGravityStrategy_8cs" ]
];