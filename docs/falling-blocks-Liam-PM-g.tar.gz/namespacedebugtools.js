var namespacedebugtools =
[
    [ "DebugInvoker", "classdebugtools_1_1DebugInvoker.html", "classdebugtools_1_1DebugInvoker" ],
    [ "DebugReceiver", "classdebugtools_1_1DebugReceiver.html", "classdebugtools_1_1DebugReceiver" ],
    [ "GetApiKeyCommand", "classdebugtools_1_1GetApiKeyCommand.html", "classdebugtools_1_1GetApiKeyCommand" ],
    [ "ICommand", "interfacedebugtools_1_1ICommand.html", "interfacedebugtools_1_1ICommand" ],
    [ "VardumpCommand", "classdebugtools_1_1VardumpCommand.html", "classdebugtools_1_1VardumpCommand" ]
];