var classgame_1_1logic_1_1EventQueue_1_1UserLoginEvent =
[
    [ "UserLoginEvent", "classgame_1_1logic_1_1EventQueue_1_1UserLoginEvent.html#a56622d425edbd43d2043a203d953f212", null ],
    [ "Id", "classgame_1_1logic_1_1EventQueue_1_1UserLoginEvent.html#a94678786e1867516ee73660f297cdbe5", null ],
    [ "Source", "classgame_1_1logic_1_1EventQueue_1_1UserLoginEvent.html#a5026e6c15a63262b7b0ea9288755bd8b", null ],
    [ "Username", "classgame_1_1logic_1_1EventQueue_1_1UserLoginEvent.html#a6ed08775aafe7990ff4e483c0545795b", null ]
];