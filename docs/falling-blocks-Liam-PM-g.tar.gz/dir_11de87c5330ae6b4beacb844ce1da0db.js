var dir_11de87c5330ae6b4beacb844ce1da0db =
[
    [ "DebugInvoker.cs", "DebugInvoker_8cs.html", "DebugInvoker_8cs" ],
    [ "DebugReceiver.cs", "DebugReceiver_8cs.html", "DebugReceiver_8cs" ],
    [ "getapikey.cs", "getapikey_8cs.html", "getapikey_8cs" ],
    [ "ICommand.cs", "ICommand_8cs.html", "ICommand_8cs" ],
    [ "Vardump.cs", "Vardump_8cs.html", "Vardump_8cs" ]
];