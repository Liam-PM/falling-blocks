var IHttpRequest_8cs =
[
    [ "network.IHttpRequest", "interfacenetwork_1_1IHttpRequest.html", "interfacenetwork_1_1IHttpRequest" ]
];