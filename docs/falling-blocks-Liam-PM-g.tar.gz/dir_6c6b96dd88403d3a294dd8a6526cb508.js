var dir_6c6b96dd88403d3a294dd8a6526cb508 =
[
    [ "logic", "dir_fbb7d9cfd9822824f6c1c3b088890308.html", "dir_fbb7d9cfd9822824f6c1c3b088890308" ],
    [ "service", "dir_e2d67771100562b8de3a498ba1ae160e.html", "dir_e2d67771100562b8de3a498ba1ae160e" ]
];