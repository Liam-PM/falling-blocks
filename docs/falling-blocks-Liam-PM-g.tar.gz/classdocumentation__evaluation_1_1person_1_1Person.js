var classdocumentation__evaluation_1_1person_1_1Person =
[
    [ "Age", "classdocumentation__evaluation_1_1person_1_1Person.html#a23cad560ae4677bf0ecc79273036764c", null ],
    [ "Name", "classdocumentation__evaluation_1_1person_1_1Person.html#a89f2bd12eebe7ae75d3b5c451c8b3346", null ]
];