var classnetwork_1_1HttpPostRequest =
[
    [ "ExecuteAsync", "classnetwork_1_1HttpPostRequest.html#ac8da46ad2a1f01023fb80c81c1a4f35c", null ],
    [ "SetClient", "classnetwork_1_1HttpPostRequest.html#a665218ab0e894496692a682311e3aeb5", null ],
    [ "SetData", "classnetwork_1_1HttpPostRequest.html#a8d1b4da866f3d55ad318c0defeb0ab44", null ],
    [ "_client", "classnetwork_1_1HttpPostRequest.html#a711d3280749b037bc4708570f4fe7fa7", null ],
    [ "_data", "classnetwork_1_1HttpPostRequest.html#a86d3142b8c22c49cc4677e6ac398ef62", null ]
];