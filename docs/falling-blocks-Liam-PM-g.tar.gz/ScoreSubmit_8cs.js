var ScoreSubmit_8cs =
[
    [ "ScoreSubmit", "classScoreSubmit.html", "classScoreSubmit" ]
];