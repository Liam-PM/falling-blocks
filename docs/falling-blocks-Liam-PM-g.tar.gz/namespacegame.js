var namespacegame =
[
    [ "logic", "namespacegame_1_1logic.html", "namespacegame_1_1logic" ],
    [ "service", "namespacegame_1_1service.html", "namespacegame_1_1service" ]
];