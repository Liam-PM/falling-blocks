var classgame_1_1logic_1_1LevelBasedGravityStrategy =
[
    [ "LevelUp", "classgame_1_1logic_1_1LevelBasedGravityStrategy.html#a9973a76a84474a7e13a8775f94e20342", null ],
    [ "ResetLevel", "classgame_1_1logic_1_1LevelBasedGravityStrategy.html#a6624c0cba3f5bd6ca5031e519f8e77b7", null ],
    [ "SetLevel", "classgame_1_1logic_1_1LevelBasedGravityStrategy.html#a786fc7b42e0e25d04e9b7dcb76f09e1b", null ],
    [ "_gravityBase", "classgame_1_1logic_1_1LevelBasedGravityStrategy.html#acc6d16785ad102461ecce3520a861a05", null ],
    [ "_level", "classgame_1_1logic_1_1LevelBasedGravityStrategy.html#ab5ffcb3667de9f6a75667fe555ec5f70", null ],
    [ "GravityIncreasePerLevel", "classgame_1_1logic_1_1LevelBasedGravityStrategy.html#ac7e1eba8beb7586012b3f8499bf8b667", null ],
    [ "CurrentGravity", "classgame_1_1logic_1_1LevelBasedGravityStrategy.html#a733a154d965eb12e99c141b53138ed95", null ],
    [ "Gravity", "classgame_1_1logic_1_1LevelBasedGravityStrategy.html#a99d30f8169e0002f4aa38aef4000b2f0", null ]
];