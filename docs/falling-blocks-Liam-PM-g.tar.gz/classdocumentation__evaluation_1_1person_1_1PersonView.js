var classdocumentation__evaluation_1_1person_1_1PersonView =
[
    [ "PersonView", "classdocumentation__evaluation_1_1person_1_1PersonView.html#ad1a27cd6bac46bc751d519de8dfa5bbb", null ],
    [ "Display", "classdocumentation__evaluation_1_1person_1_1PersonView.html#a97df5690154ae85c6069220f2e70abb4", null ],
    [ "UpdateAge", "classdocumentation__evaluation_1_1person_1_1PersonView.html#aa0251605f48d1b12b22fdbf86301baae", null ],
    [ "UpdateName", "classdocumentation__evaluation_1_1person_1_1PersonView.html#a3a80a8b222ab9f7cb8b7835c8a1e6eb1", null ],
    [ "_viewModel", "classdocumentation__evaluation_1_1person_1_1PersonView.html#a2f8c2ab8b7d79eeaec100a782ed3c7ec", null ]
];