var dir_6276bedd4b417fb9f320f9e90279f791 =
[
    [ "ScoreService.cs", "ScoreService_8cs.html", "ScoreService_8cs" ]
];