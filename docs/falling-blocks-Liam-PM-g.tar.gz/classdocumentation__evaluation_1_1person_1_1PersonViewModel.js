var classdocumentation__evaluation_1_1person_1_1PersonViewModel =
[
    [ "PersonViewModel", "classdocumentation__evaluation_1_1person_1_1PersonViewModel.html#ae884c60f8eacf51e0bc0b817cde64628", null ],
    [ "_person", "classdocumentation__evaluation_1_1person_1_1PersonViewModel.html#a0f9ed6c8f62fb2cc7c137183360d38a8", null ],
    [ "Age", "classdocumentation__evaluation_1_1person_1_1PersonViewModel.html#a8e720e9b7b5efb26ea688bdc78b79a75", null ],
    [ "Name", "classdocumentation__evaluation_1_1person_1_1PersonViewModel.html#a838422101033a721f7c23c21c10e23ef", null ]
];