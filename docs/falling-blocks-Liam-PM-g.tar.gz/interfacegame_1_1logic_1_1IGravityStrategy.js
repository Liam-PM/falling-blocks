var interfacegame_1_1logic_1_1IGravityStrategy =
[
    [ "CurrentGravity", "interfacegame_1_1logic_1_1IGravityStrategy.html#a8a240732864021c62036968b17b9a90c", null ],
    [ "Gravity", "interfacegame_1_1logic_1_1IGravityStrategy.html#a0ecc8f43e706defbb23aac46034daf6b", null ]
];